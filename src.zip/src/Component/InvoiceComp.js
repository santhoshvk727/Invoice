import React, { useState, useEffect,useRef } from 'react';
import './Invoice.css';
import axios from 'axios';
// import { useReactToPrint } from 'react-to-print';
import ReactToPrint from 'react-to-print';



const InvoiceComp = () => {
    const [users, setUsers] = useState([]);
    const [filteredUser, setFilteredUser] = useState(null);
    const [invoiceNo, setInvoiceNo] = useState(0);
    const [invoiceDate, setInvoiceDate] = useState('');
  
    useEffect(() => {
      // Fetch data from the API
      axios.get('http://localhost:5253/api/invoice/getnotes')
        .then(response => setUsers(response.data))
        .catch(error => console.error('Error fetching data:', error));
    }, []);
  
     
    useEffect(() => {
      // Filter the user data based on the matched sid
      const matchedUser = users.find(user => user.sId == sessionStorage.getItem('sid'));
      setFilteredUser(matchedUser);
    }, [users, sessionStorage.getItem('sid')]);
    

    useEffect(() => {
      setInvoiceNo(prevInvoiceNo => prevInvoiceNo + 1);
    
      const currentDate = new Date();
      const formattedDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getDate()}`;
      setInvoiceDate(formattedDate);
    }, []);
    
   
    const componentRef= useRef()

   

    const handlePrint = () => {
      window.print();
    };

    return (
        <div className='container m-5'>
         <ReactToPrint trigger={() =><button>Print/Download</button>} content={() =>componentRef.current}/> 
        {filteredUser ? (
        <div ref={componentRef}>
         
         <div>
        <h1>Invoicer</h1>
        <h3>{filteredUser.studentFirstName}</h3>
          <ul>
             <li>Invoice No:{invoiceNo}</li>
             <li>Invoice Date:{invoiceDate}</li>
           </ul>
         </div>
        <div>
          <h4>NET TECHNOLOGIES</h4>
        </div>
        
         <div>
           <ul>
             <li>StudentId:{filteredUser.sId}</li>
             
             <li>studentFirstName :{filteredUser.studentFirstName}</li>
             <li>studentLastName:{filteredUser.studentLastName}</li>
             <li>CourseId:{filteredUser.courseId}</li>
             <li>CourseName:{filteredUser.courseName}</li>
             <li>CourseDuration:{filteredUser.courseDuration}</li>
             <li>CourseFees:{filteredUser.courseFees}</li>
             <li>Paymenttype:{filteredUser.paymenttype}</li>
             <li>PaymentAmount:{filteredUser.paymentAmount}</li>
             <li>DueDate:{filteredUser.dueDate}</li>
             <li>PaymentDate:{filteredUser.paymentDate}</li>
             <li></li>
           </ul>
         </div>
      </div>
         ) : (
            <p>No matching user found.</p>
          )}
        </div>
    )
}

export default InvoiceComp