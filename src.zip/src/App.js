// import logo from './logo.svg';
import './App.css';
// import UserTableComp from './Component/UsertableComp';
// import StudentLogin from './Component/StudentLogin';
import InvoiceComp from './Component/InvoiceComp';
// import Admin from './Component/Admin';


function App() {
  return (
    <div className="App">
      
      {/* <StudentLogin/> */}
      <InvoiceComp/>
      {/* <Admin/> */}
    </div>
  );
}


export default App;
